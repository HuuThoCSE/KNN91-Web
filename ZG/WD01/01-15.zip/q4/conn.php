<?php

$cnn = new mysqli('localhost', 'root', '', 'mannerings');

if($cnn->connect_error) die("Kết nối thất bại");


?>