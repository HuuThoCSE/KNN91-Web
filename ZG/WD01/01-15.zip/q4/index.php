<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    body {
        font-family: sans-serif;
    }
    
    table {

    }

</style>
<body>
    <h1>Mannering Estate Agency</h1>

    <ul>
        <li><a href="display.php">Display all properties</a></li>
        <li><a href="search.php">Search for properties by town</a></li>
    </ul>
</body>
</html>